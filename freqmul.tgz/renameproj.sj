Newname=$*

find . -type f -exec sed -i 's/Syng/$Newname/g' {} +

find . -depth -exec sh -c '
  for f do
    base=$(basename "$f")
    # renommer insensible à la casse
    new=$(printf "%s" "$base" | sed "s/Syng/$Newname/g")
    if [ "$new" != "$base" ]; then
      mv "$f" "$(dirname "$f")/$new"
    fi
  done
' sh {} +

