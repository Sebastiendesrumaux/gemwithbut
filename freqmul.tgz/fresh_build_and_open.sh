bash ./build.sh
