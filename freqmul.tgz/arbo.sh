
echo `pwd` >arbo.tmp
echo `env` >>arbo.tmp
find . -type f \( \
   -name "*.java" -o \
   -name "*.xml"  -o \
   -name "*.properties" -o \
   -name "build.gradle" -o \
   -name "settings.gradle" -o \
   -name "gradle.properties" -o \
   -name "*.gradle" \
\) -print  >>arbo.tmp

echo "J'aimerais que tu la prennes en compte pour la suite et que dans tout le processus de développement que nous allons effectuer,  tu me communiques tes modifications sous forme de commandes à copier coller dans termux, parfois juste des batch utilisant sed et awk, d'autre fois des fichiers entiers à (re)-créer avec une commande shell" >>arbo.tmp
cat arbo.tmp | termux-clipboard-set

rm arbo.tmp

