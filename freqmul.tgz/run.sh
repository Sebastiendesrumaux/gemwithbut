termux-open /storage/emulated/0/Download/Syng-fresh-debug.apk
